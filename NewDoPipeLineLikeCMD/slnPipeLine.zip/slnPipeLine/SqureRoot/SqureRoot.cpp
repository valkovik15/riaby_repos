// SqureRoot.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <math.h>

using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
   char ch;
   float x;
   cin >> ch>>ch>>ch>>ch;
	cin >> x;
	cout << sqrt(x);
	//getchar();
	//getchar();
	return 0;
}

