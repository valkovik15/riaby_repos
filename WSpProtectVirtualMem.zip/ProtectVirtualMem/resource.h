//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ProtectVirtualMem.rc
//
#define IDC_MYICON                      2
#define IDD_PROTECTVIRTUALMEM_DIALOG    102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_PROTECTVIRTUALMEM           107
#define IDI_SMALL                       108
#define IDC_PROTECTVIRTUALMEM           109
#define IDR_MAINFRAME                   128
#define IDM_PAGE_NOACCESS               32771
#define IDM_PAGE_READWRITE              32772
#define IDM_PAGE_READONLY               32773
#define IDM_PAGE_GUARD_PAGE_READWRITE   32774
#define IDM_READ                        32775
#define IDM_WRITE                       32776
#define IDM_LOCK                        32777
#define IDM_UNLOCK                      32778
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
