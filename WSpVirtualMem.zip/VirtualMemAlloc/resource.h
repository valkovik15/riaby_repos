//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VirtualMemAlloc.rc
//
#define IDD_VM_ALLOC                    101
#define IDI_ICON_VIRTUAL_MEM            103
#define IDC_STATIC_PG_SIZE_NAME         1000
#define IDC_STATIC_PG_SIZE_VALUE        1001
#define IDC_BUTTON_RESERVE_REGION       1002
#define IDC_STATIC_BOX_ARRAY            1003
#define IDC_STATIC_INDEX                1004
#define IDC_EDIT_INDEX                  1005
#define IDC_BUTTON_USE                  1006
#define IDC_BUTTON_DISPOSE              1007
#define IDC_BUTTON_COLLECT              1008
#define IDC_STATIC_MEM_MAP              1009
#define IDC_STATIC_COMMENT              1010
#define IDC_BUTTON_RELEASE              1011
#define IDC_STATIC_MAP_WND              1012
#define IDC_STATIC_PAGE_STATE           1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
