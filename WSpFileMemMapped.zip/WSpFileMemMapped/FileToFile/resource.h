//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileToFile.rc
//
#define IDC_MYICON                      2
#define IDD_FILETOFILE_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDD_ONCLOSE                     104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_FILETOFILE                  107
#define IDI_SMALL                       108
#define IDC_FILETOFILE                  109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_OPTIONS              130
#define IDC_STATICEXIT                  1000
#define IDC_RADIO_DIRECT                1000
#define IDC_BUTTONEXIT                  1001
#define IDC_EDIT_KEY                    1002
#define IDC_STATIC_KEY                  1004
#define IDC_RADIO_BACKWARD              1005
#define IDM_ENCRIPT                     32772
#define IDM_OPTIONS                     32774
#define IDM_OPENFILE                    32775
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
