// ProcessB.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
 
int main(int argc, char* argv[])
{
 
 while(true)
	printf("\nHello World! from ProcessB working forever... \n");
 
	return 0;
}

